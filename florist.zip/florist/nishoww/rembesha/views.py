from django.shortcuts import render, HttpResponseRedirect, redirect, reverse, HttpResponse, Http404
from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .forms import CreateUserForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from .forms import CreateUserForm
from django.db import IntegrityError
from django.core.mail import EmailMessage, EmailMultiAlternatives
from .tokens import account_activation_token
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
from django.utils.encoding import force_bytes
from .models import *
from django.utils.encoding import force_str
from rembesha.models import *
from django.core.mail import send_mail
from django.db.models import Q
from django.contrib.auth.forms import PasswordChangeForm
import json
from django.http import JsonResponse
import ast
import random
from PIL import Image as imageimage
from io import BytesIO
from django.core.files import File
from django.core.files.base import ContentFile
from django.core.files.uploadedfile import InMemoryUploadedFile
from django.utils.crypto import get_random_string
import base64
import os
from Beautify import settings
from Beautify.settings import EMAIL_HOST_USER


# Create your views here.
def indexpage(request):
    categories = ProductCategory.objects.all()
    products = Product.objects.all()
    context = {
        "categories": categories,
        "products": products,
    }
    return render(request, 'rembesha/index.html', context)



def category(request, id):
    product_category = ProductCategory.objects.get(id=id)
    products = Product.objects.filter(category = product_category)
    context = {
        'product_category': product_category,
        'products': products,
    }
    return render(request, 'rembesha/category.html', context)


def product(request, id):
    the_product = Product.objects.get(id = id)
    return render(request, 'rembesha/product.html', {'the_product': the_product})


def cart(request):
    return render(request, 'rembesha/cart.html')


def about_us(request):
    return render(request, 'rembesha/about_us.html')


def contact_us(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        client_subject = request.POST.get('subject')
        message = request.POST.get('message')
        try:
            ContactUs.objects.create(name = name, email = email, subject = client_subject, message = message).save()
            
            subject, from_email, to = 'MESSAGE RECEIVED SUCCESSFULLY', EMAIL_HOST_USER, email
            text_content = ''
            html_content = """
            <p>Thank you for contacting us. Your mesage was received successfully. We will get back to you shortly.</p>
            <p>Regards, Busy Bee Florist</p>
            """
            msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
            msg.attach_alternative(html_content, "text/html")
            msg.send()

            subject = f"Contact Us - Message From Client - {client_subject} - client email - {email}"
            send_mail(subject, message, EMAIL_HOST_USER , ['jeremiahmbandinthiwa@gmail.com'])

            context = {
                'contact_successful': 'yes'
            }
            return render(request, 'rembesha/contact_us.html', context)
        except:
            context = {
                    'contact_successful': 'no'
            }
            return render(request, 'rembesha/contact_us.html', context)

    return render(request, 'rembesha/contact_us.html')


def myprofile(request):
    return render(request, 'rembesha/myprofile.html')


def place_order(request):
    if request.method == "POST" and request.user.is_authenticated:
        successful = 'yes'
        all_items = request.POST.get('all_items')
        all_items = all_items.split(',')
        # check if all products in the list exist and if the number of each product is greater than zero
        for the_item in all_items:
            item_id_and_number_of_items  = the_item.split('-')
            item_id = item_id_and_number_of_items[0]
            number_of_items = item_id_and_number_of_items[1]
            # check if product exists
            if Product.objects.filter(id = item_id).count() != 1 or int(number_of_items) < 1:
                successful = "no"
                break

        if successful == "yes":
            random_number = get_random_string(8)
            # check if order with that random number exists
            order_exists = True
            while order_exists is True:
                if Order.objects.filter(order_number = random_number).count() < 1:
                    order_exists = False
                else:
                    random_number = get_random_string(8)

            order = Order.objects.create(
                user = request.user, order_number  = random_number, order_status = 'pending'
            )

            order.save()

            for the_item in all_items:
                item_id_and_number_of_items  = the_item.split('-')
                item_id = item_id_and_number_of_items[0]
                number_of_items = item_id_and_number_of_items[1]
                product = Product.objects.get(id = item_id)
                order_item = OrderItem.objects.create(
                    product = product, quantity = number_of_items,
                )
                order_item.save()

                order.items.add(order_item)
                order.save()

            # send emails
            
            subject, from_email, to = 'Order Placed Successfully', EMAIL_HOST_USER, request.user.email
            text_content = ''
            html_content = """
            <p>Thank you placing an order. Our team will contact you shortly to guide you with the payment and delivery of your order. Thank you.</p>
            <p>Regards, Busy Bee Florist</p>
            """
            msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
            msg.attach_alternative(html_content, "text/html")
            msg.send()

            subject = f"Client order - {order.order_number} - client email - {request.user.email}"
            message = f'{request.user.first_name} {request.user.last_name} has placed an order, kindly attend to it'
            send_mail(subject, message, EMAIL_HOST_USER , ['jeremiahmbandinthiwa@gmail.com'])

        data = {
            'successful':  successful
        }
        return JsonResponse(data)
    
    data = {
        'successful': 'no'
    }
    return JsonResponse(data)

# def removeproduct(request):
#     the_id = request.POST.get('removeproduct')
#     the_id = int(the_id)
#     prod = Product.objects.get(id=the_id)
#     prod.delete()
#     return redirect('rembesha:business_space')


def activation_sent_view(request):
    return render(request, 'activation_sent.html')


def registrationPage(request):
    if request.method == 'POST':
        f_name = request.POST.get("first_name")
        l_name = request.POST.get("last_name")
        email = request.POST.get("email")
        username = request.POST.get("username")
        password = request.POST.get("password1")
        try:
            User.objects.get(username=username)
            error_msg_username = "user with that username already exists, enter another username"
            return render(request, 'rembesha/register.html', {'error_msg_username': error_msg_username})

        except:
            user = User.objects.create_user(first_name=f_name, last_name=l_name, email=email, username=username,
                                            password=password)
            user.is_active = False
            user.save()
            current_site = get_current_site(request)
            subject = 'Please activate your account'
            message = render_to_string('rembesha/activation_request.html',
                                        {'user': user,
                                        'domain': current_site.domain,
                                        'uid': urlsafe_base64_encode(force_bytes(user.pk)),
                                        'token': account_activation_token.make_token(user)}
                                        )
            user.email_user(subject, message)
            return render(request, 'rembesha/activation_sent.html')
        

    return render(request, 'rembesha/register.html')


def activate(request, uidb64, token):
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None

    if user is not None and account_activation_token.check_token(user, token):
        user.is_active = True
        user.save()
        login(request, user)
        return render(request, 'rembesha/account_activated.html')
    else:
        return render(request, 'rembesha/activation_invalid.html')


def loginPage(request):
    
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)

        if user is not None and user.is_active:
            login(request, user)
            return redirect('rembesha:indexpage')

        else:
            error_message = 'You have entered a wrong password or username'
            return render(request, 'rembesha/login.html', {'error_message': error_message})
    else:
        return render(request, 'rembesha/login.html')



def logoutUser(request):
    logout(request)
    return redirect('rembesha:indexpage')


def searchpage(request):
    if request.method == "POST":
        search = request.POST.get('search')
        if (search != "" and search != " "):
            results = Product.objects.filter(Q(name__contains=search) | Q(description__contains=search) | Q(price__contains=search) )
            return render(request, 'rembesha/search.html', {'results': results})
            
        else:
            return redirect('rembesha:indexpage')

    else:
        return redirect('rembesha:indexpage')

