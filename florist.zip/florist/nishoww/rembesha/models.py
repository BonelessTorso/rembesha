from django.db import models
import cloudinary.uploader
import cloudinary.api
from django.contrib.auth.models import User


class ProductCategory(models.Model):
    name = models.CharField(max_length=100)
    category_img = models.FileField()

    def __str__(self):
        return self.name

class Product(models.Model):
    category = models.ForeignKey(ProductCategory, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    product_img = models.FileField()
    description = models.TextField(max_length=5000)
    price = models.CharField(max_length=10)


class ContactUs(models.Model):
    name = models.CharField(max_length=300)
    email = models.EmailField(max_length=200)
    subject = models.CharField(max_length=300)
    message = models.TextField(max_length=6000)


class OrderItem(models.Model):
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    quantity = models.IntegerField()

    def __str__(self):
        return 'product - ' + self.product.name + ' -- quantity: ' + str(self.quantity)


order_status_choices = (
    ('pending payment', 'pending payment'),
    ('on_transit', 'on transit'),
    ('delivered', 'delivered'),
    ('cancelled', 'cancelled'),

)

class Order(models.Model):
    user = models.ForeignKey(User, on_delete=models.PROTECT)
    order_number = models.CharField(max_length=100)
    items = models.ManyToManyField(OrderItem)
    date_time_placed = models.DateField(auto_now_add=True)
    order_status = models.CharField(max_length=100, default='pending', choices=order_status_choices)

    def __str__(self):
        return self.order_number


