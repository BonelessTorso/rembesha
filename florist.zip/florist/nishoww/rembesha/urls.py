from django.contrib import admin
from django.urls import path,include
from . import views
from .views import *
from django.contrib.auth import views as auth_views
from django.contrib.auth.views import PasswordResetView,PasswordResetDoneView,PasswordResetConfirmView,PasswordResetCompleteView
from django.urls import path,reverse,reverse_lazy
from django.conf.urls.static import static
from django.conf import settings
app_name = 'rembesha'

urlpatterns = [
    path('', views.indexpage , name = 'indexpage'),
    path('searchpage', views.searchpage, name="searchpage"),
    path('category/<int:id>/', views.category, name="category"),
    path('place_order', views.place_order, name='place_order'),
    path('product/<int:id>/', views.product, name="product"),
    path('cart', views.cart, name="cart"),
    path('about_us', views.about_us, name="about_us"),
    path('contact_us', views.contact_us, name="contact_us"),
    path('register', views.registrationPage, name='register'),
    path('login', views.loginPage, name='login'),
    path('myprofile', views.myprofile, name='myprofile'),
    path('logout/',views.logoutUser, name = 'logout'),
    path('activation_sent',views.activation_sent_view,name='activation_sent'),
    path('activate/<slug:uidb64>/<slug:token>/',views.activate, name = 'activate'),
    path('password_reset/', auth_views.PasswordResetView.as_view(email_template_name = 'rembesha/password_reset_email.html',
                                                                 success_url = reverse_lazy('rembesha:password_reset_done')), name='password_reset'),

    path('password_reset_done/', auth_views.PasswordResetDoneView.as_view(template_name = 'rembesha/password_reset_done.html'), name='password_reset_done'),

    path('password_reset_<uidb64>_<token>/', auth_views.PasswordResetConfirmView.as_view(template_name = 'rembesha/password_reset_confirm.html',
                                                                                         success_url = reverse_lazy('rembesha:password_reset_complete')), name='password_reset_confirm'),

    path('password_reset_complete/', auth_views.PasswordResetCompleteView.as_view(template_name = 'rembesha/password_reset_complete.html'), name='password_reset_complete'),


] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)