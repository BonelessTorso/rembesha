from django.apps import AppConfig


class RembeshaConfig(AppConfig):
    name = 'rembesha'
